#'GC_content table
#'
#'GC_content data
#'
#'@docType data
#'
#'@usage data(GC_content)
#'
#'@format An object of class "data.frame"
#'
#'@keywords datasets
"GC_content"
