#'False detection rate (FDR) adjusted p-values
#'
#' Welch's  two sample t-tests are used to calculate p-values and FDR correction
#' is done using the "fdrtool" package
#'
#'@param atomX  A list object created by \code{qSIP_atom_excess_MAGs()}
#'@param alpha Numerical value - Significance level for hypothesis testing
#'@import magrittr
#'@importFrom rlang .data
#'@importFrom fdrtool fdrtool
#'@return A dataframe of FDR adjusted p-values for each MAG and a BOOLEAN
#'of whether or not the MAG is an incorporator based on a set significance level.
#'Weights used to run t-tests are also presented
#'@export

fdr_multiple_hypothesis_testing = function(atomX, alpha) {

#Set margins for fdr plots from fdrtool package
par(mar=c(1,1,1,1))

#Create a tibble for weights using buoyant densities
Weights = tibble::as_tibble(atomX$W)

#Run t-tests on the buoyant densities for a particular MAG using
#all replicates of control and experimental condition

p_table = dplyr::tibble(OTU = unique(Weights$OTU))
p_table = p_table %>%
  dplyr::mutate(weights = purrr::map(OTU, ~ dplyr::filter(Weights, OTU == .))) %>%
  dplyr::mutate(p_values = purrr::map(weights, ~ stats::t.test(W~IS_CONTROL, .)$p.value)) %>%
  dplyr::mutate(p_values = as.numeric(p_values))

#Run FDR correction for multiple hypothesis testing using fdrtool package
fdr_table = fdrtool::fdrtool(p_table$p_values, statistic = "pvalue", verbose = FALSE)

p_table = p_table %>%
  dplyr::mutate(adj_p_values = fdr_table$qval) %>%
  dplyr::mutate(incorporator = adj_p_values < alpha)

return(p_table)
}
