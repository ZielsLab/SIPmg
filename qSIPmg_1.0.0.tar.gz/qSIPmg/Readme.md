Package description:
qSIPmg is a statistical analysis package to identify isotope incorporating MAGs using the principles of quantitative stable isotope probing (qSIP).

For more information about qSIPmg and how to use it, please see the qSIPmg [vignette]
