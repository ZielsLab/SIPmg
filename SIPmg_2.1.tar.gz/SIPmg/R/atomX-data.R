#'Atom fraction excess table
#'
#'Data table generated from the "qSIP_atom_excess_MAGs" function
#'
#'@docType data
#'
#'@usage data(atomX)
#'
#'@format An object of class "list"
#'
#'@keywords datasets
"atomX"
