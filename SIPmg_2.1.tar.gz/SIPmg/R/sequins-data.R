#'Sequins table
#'
#'Sequins metadata
#'
#'@docType data
#'
#'@usage data(sequins)
#'
#'@format An object of class "data.frame"
#'
#'@keywords datasets
"sequins"
