#'Coverage table
#'
#'Coverage data used for many functions in the package
#'
#'@docType data
#'
#'@usage data(f_tibble)
#'
#'@format An object of class "data.frame"
#'
#'@keywords datasets
"f_tibble"
