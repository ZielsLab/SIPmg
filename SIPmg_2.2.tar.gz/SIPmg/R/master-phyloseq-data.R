#'Master phyloseq object
#'
#'
#'@docType data
#'
#'@usage data(phylo.qSIP)
#'
#'@format An object of class "phyloseq"
#'
#'@keywords datasets
"phylo.qSIP"
