#'Fractions table
#'
#'Fractions data used for many functions in the package
#'
#'@docType data
#'
#'@usage data(fractions)
#'
#'@format An object of class "data.frame"
#'
#'@keywords datasets
"fractions"
