#'Sequins dilution table
#'
#'Sequins dilution data
#'
#'@docType data
#'
#'@usage data(seq_dil)
#'
#'@format An object of class "data.frame"
#'
#'@keywords datasets
"seq_dil"
