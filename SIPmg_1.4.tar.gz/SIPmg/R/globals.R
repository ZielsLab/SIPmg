utils::globalVariables("GC_content")
